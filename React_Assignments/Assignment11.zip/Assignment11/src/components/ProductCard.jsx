export default function ProductCard() {
  throw new Error("Product failed to render");
}
