const LoadingStatus = ({ loading, children }) => {
  return children(loading)
}

export default LoadingStatus
