const FadeWrapper = ({ children }) => (
  <div className="animate-fadeIn">{children}</div>
)

export default FadeWrapper
