export default function CourseDetails() {
  return (
    <div className="mt-4 p-4 bg-indigo-600 text-white rounded-lg shadow">
      Course Details Loaded
    </div>
  );
}
