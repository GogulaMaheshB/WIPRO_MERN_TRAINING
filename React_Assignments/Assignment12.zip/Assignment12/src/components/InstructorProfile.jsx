export default function InstructorProfile() {
  return (
    <div className="mt-4 p-4 bg-green-600 text-white rounded-lg shadow">
      Instructor Profile Loaded
    </div>
  );
}
